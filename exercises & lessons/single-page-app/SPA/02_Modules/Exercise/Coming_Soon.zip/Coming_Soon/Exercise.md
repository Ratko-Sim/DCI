## Instructions for students:

### Coming Soon Page

Create a coming soon webpage. The page should show a count down of days, hours, minutes, and seconds.

- make sure you use a class that accepts:
  - selector
  - end-date
- for easier date handling you can use [momentjs](https://momentjs.com)

- **Optional:** Style to your pleasing.

- Example once your program is running properly:

![https://dribbble.com/shots/5188890-Modern-Coming-Soon-Template](./comingsoon.png)

### Rules

- This is an individual assignment.
- Deadline: 2hrs
